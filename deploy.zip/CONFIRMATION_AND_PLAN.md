# 🛑 全局状态确认与架构修正计划

## 1. 核心现状确认 (Status Confirmation)

我已完全理解您描述的**四合院项目矩阵**与**物理架构现状**，并明确了当前的严重错误：

*   **唯一真实基座**: 容器 `iasbt-postgres` (IP: 172.17.0.3, Port: 5432)。这是包含所有历史数据的唯一真理。
*   **当前错误**: 部署脚本错误地启动了 `postgres-business` (空壳数据库) 和 `postgrest` (错误API)，导致系统分裂。
*   **修正目标**: 废弃所有错误容器，重新构建 Node.js 后端与 React 前端，并让后端**直连**现有的 `iasbt-postgres`。

## 2. 架构理解 (Architecture Matrix)

| 项目 | 角色 | 数据库 Schema | 关键特征 |
| :--- | :--- | :--- | :--- |
| **A: 账户系统** | **大门/管家 (基座)** | `public` | 负责登录、鉴权、Token签发。后端在腾讯云，前端在 Vercel (或自托管)。 |
| **B: 图库 (Gallery)** | **后花园** | `gallery` | 图片存 R2，元数据存 DB。强依赖 A 的 Token。 |
| **C: 工具箱** | **储藏室** | `toolbox` | - |
| **D: Life OS** | **主卧** | `life_os` | - |

**物理流转**: 用户 -> 前端 (Vercel/Nginx) -> 后端 (腾讯云 API) -> 数据库 (iasbt-postgres) -> 资源 (R2)。

## 3. 下一步执行计划 (Execution Plan)

我将严格按照您的 4 步指令，在 `deploy/correction` 目录下生成以下文件，供您直接执行：

1.  **`cleanup.sh`**:
    *   `docker stop/rm` 掉 `postgres-business`, `postgrest`, `nginx-gateway`。
    *   清理相关无用网络。

2.  **`Dockerfile.api` (后端)**:
    *   基于 `node:18-alpine`。
    *   构建 `server.js`，暴露 3000 端口。

3.  **`Dockerfile.web` & `nginx.conf` (前端)**:
    *   多阶段构建：Node 构建 React -> Nginx 托管 Dist。
    *   Nginx 配置：SPA 路由支持 (`try_files`) + `/api/` 反向代理到后端。

4.  **`docker-compose.yml` (最终编排)**:
    *   **绝不创建新数据库**。
    *   `account-backend`: 注入 DB 连接信息 (Target: 172.17.0.3)。
    *   `account-frontend`: 挂载 nginx.conf，暴露 80 端口。

---

**确认状态**: 已明确基座，准备生成配置文件。
