
# Account System - 终极全息开发档案 (The Grand Master Edition)

> 状态: 已归档
> 归档时间: 2026-02-09
> 归档责任人: Account Maintainer

> **版本**: v5.0.0 (Grand Master)
> **最后更新**: 2026-02-05
> **密级**: 核心绝密 (Top Secret)
> **用途**: 本文档集成了项目架构、代码实现、数据库脚本、故障排查历史及操作手册。这是项目的“大脑备份”。任何接手此项目的 AI 助手或开发者，在编写任何代码前，必须首先阅读本文档。

---

## 1. 项目全景 (Project Overview)

### 1.1 身份定义
- **项目名称**: Account System (IAM / SSO Platform)
- **线上地址**: `https://account.iasbt.com`
- **核心定位**: "Life OS" 生态系统的**中央心脏**。
- **职责**:
    1.  **身份中心**: 统一管理所有用户注册/登录。
    2.  **SSO 枢纽**: 外部应用（如 Gallery，已废弃）跳转至此登录，成功后自动跳回。
    3.  **权限中台**: 区分 User/Admin，控制谁能访问什么。

### 1.2 技术栈详解
| 层级 | 技术 | 说明 |
| :--- | :--- | :--- |
| **前端** | React 18 + Vite | 极速构建 SPA 单页应用 |
| **语言** | TypeScript | 强类型，防止低级报错 |
| **样式** | TailwindCSS | 原子化 CSS，便于移动端适配 |
| **状态** | Zustand | 替代 Context API，管理全局 User/Session |
| **后端** | Supabase | 提供 Auth (GoTrue) 和 Database (Postgres) |
| **部署** | Vercel | 静态托管 + Serverless Edge |

### 1.3 核心文件目录地图
```text
/
├── public/              # 静态资源
├── .env                 # 环境变量 (VITE_SUPABASE_URL 等)
├── vercel.json          # Vercel 路由重写 (解决 404 关键)
├── index.html           # 网页入口
├── src/
│   ├── lib/
│   │   └── supabase.ts  # Supabase 客户端初始化
│   ├── store/
│   │   └── useAuthStore.ts  # ⚠️ 核心：登录逻辑、状态管理
│   ├── components/
│   │   ├── auth/
│   │   │   ├── LoginForm.tsx   # 登录表单 (含 SSO 逻辑)
│   │   │   └── AdminGuard.tsx  # 路由守卫 (保护后台)
│   │   └── layout/
│   │       └── Navbar.tsx      # 顶部导航
│   ├── pages/
│   │   ├── LoginPage.tsx       # 登录页
│   │   ├── DashboardPage.tsx   # 个人中心
│   │   └── AdminPage.tsx       # 管理后台 (隐藏入口)
│   ├── App.tsx          # 路由配置
│   └── main.tsx         # ⚠️ 入口：含自动排毒逻辑
````

---

## 2. 核心逻辑与代码实现 (Core Logic & Implementation)

### 2.1 认证初始化：并行加速与熔断 (The "Parallel Turbo" Engine)

**背景**: 早期版本串行请求（先查 Session 再查 Profile），导致冷启动耗时 >10s，用户以为网页挂了。 **逻辑**: 使用 `Promise.all` 同时发起请求，并给数据库查询加 2秒超时炸弹。 **核心代码 (`src/store/useAuthStore.ts`)**:

TypeScript

```
initialize: async () => {
  set({ loading: true });
  try {
    // 1. 定义超时炸弹 (2秒)
    const timeoutPromise = new Promise((_, reject) =>
      setTimeout(() => reject(new Error('Profile query timeout')), 2000)
    );

    // 2. 竞速机制: Session 必须等到，Profile 最多等 2 秒
    const [sessionResult, profileResult] = await Promise.all([
      supabase.auth.getSession(),
      Promise.race([
        supabase.from('profiles').select('*').single(),
        timeoutPromise
      ]).catch(err => ({ data: null, error: err }))
    ]);

    const session = sessionResult.data.session;
    if (!session) { set({ user: null, session: null }); return; }

    // 3. 兜底策略: 如果数据库超时，默认给 'user' 权限，保证能进系统
    // @ts-ignore
    const role = profileResult.data?.role || 'user';
    
    set({ session, user: { ...session.user, role } });
  } finally {
    set({ loading: false }); // 无论死活，必须关闭 Loading
  }
}
```

### 2.2 退出登录：核弹级清理 (Nuclear SignOut)

**背景**: iOS Safari 和微信内置浏览器缓存极重。普通路由跳转会导致旧 Token 残留，用户再次登录会陷入“登录-退出”死循环。 **逻辑**: 清空所有存储 -> **强制硬刷新页面**。 **核心代码 (`src/store/useAuthStore.ts`)**:

TypeScript

```
signOut: async () => {
  try { await supabase.auth.signOut(); } finally {
    set({ user: null, session: null });
    localStorage.clear(); 
    sessionStorage.clear();
    window.location.href = '/login'; // ⚠️ 关键：强制浏览器重载，不走 React 路由
  }
}
```

### 2.3 自动排毒系统 (Auto-Detox System)

**背景**: 每次发版更新 Auth 逻辑时，老用户的本地缓存与新代码不兼容，导致白屏。 **逻辑**: 在 React 启动前比对版本号，不一致则自毁缓存。 **核心代码 (`src/main.tsx`)**:

TypeScript

```
const APP_VERSION = 'v1.2.0'; // 每次发版修改这里
const storedVersion = localStorage.getItem('app_version');

if (storedVersion !== APP_VERSION) {
  console.log(`♻️ Auto-Detox: ${storedVersion} -> ${APP_VERSION}`);
  localStorage.clear();
  sessionStorage.clear();
  localStorage.setItem('app_version', APP_VERSION);
  window.location.reload();
}
```

### 2.4 SSO 跳转流程 (Redirect Flow)

**背景**: 外部应用（如 Gallery，已废弃）需要登录时，会携带 `?redirect=...` 参数过来。 **逻辑**: 登录成功后，优先跳转回外部 URL。 **核心代码 (`src/features/auth/components/LoginForm.tsx`)**:

TypeScript

```
// 登录成功后...
const params = new URLSearchParams(window.location.search);
const redirectUrl = params.get('redirect');

if (redirectUrl) {
  window.location.href = redirectUrl; // 跳出本站
} else {
  navigate('/', { replace: true });   // 进入个人中心
}
```

---

## 3. 数据库重建指南 (Database Restoration)

**重要**: Supabase 的 `auth.users` 表是系统表，我们不能直接改。业务逻辑全靠 `public.profiles`。 **操作**: 复制以下 SQL 到 Supabase SQL Editor 运行。

SQL

```
-- 1. 建立用户档案表
create table public.profiles (
  id uuid not null references auth.users on delete cascade,
  email text,
  role text default 'user', -- ⚠️ 核心权限字段
  avatar_url text,
  primary key (id)
);

-- 2. 建立审计日志表
create table public.user_app_access (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users not null,
  app_id text not null,
  app_name text not null,
  last_accessed_at timestamp with time zone default timezone('utc'::text, now())
);

-- 3. 自动化触发器 (注册即创建 Profile)
-- 如果没有这个，新用户注册后无法登录，后台会报错
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'user');
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- 4. 开启安全策略 (RLS)
alter table public.profiles enable row level security;
-- 所有人可看 Profile (基础信息)
create policy "Public profiles are viewable by everyone" on profiles for select using (true);
-- 自己改自己
create policy "Users can update own profile" on profiles for update using (auth.uid() = id);

alter table public.user_app_access enable row level security;
-- 用户只能记录和看自己的日志
create policy "insert_own" on user_app_access for insert with check (auth.uid() = user_id);
create policy "select_own" on user_app_access for select using (auth.uid() = user_id);
```

---

## 4. 故障排查历史 (The Bug Graveyard)

这里记录了每一个折磨过我们的 Bug，以及它们的解决办法。

### Bug #001: 无限 Loading 转圈 (Logic Deadlock)

- **现象**: 访问页面一直转圈，控制台无报错。
    
- **原因**: 代码逻辑分支（如网络错误）中漏写了 `set({ loading: false })`。
    
- **修复**: 全局引入 `try-finally` 结构，确保 Loading 必关闭。
    

### Bug #002: 手机端登录死循环 (Zombie State)

- **现象**: 退出后立即自动登录，或者登录后立即被踢出。
    
- **原因**: 手机浏览器顽固缓存了旧的 Auth State。
    
- **修复**: 实施 **核弹级退出 (2.2)** 和 **自动排毒 (2.3)**。
    

### Bug #003: 刷新页面报 404 (SPA Routing)

- **现象**: 访问 `/login` 或 `/admin`，直接显示 Vercel 404 页。
    
- **原因**: Vercel 试图寻找 `login.html` 文件，但我们是 SPA。
    
- **修复**: 根目录添加 `vercel.json`，配置 Rewrites。
    

### Bug #004: 数据库 Profiles 为空

- **现象**: 无法设置管理员，或者用户登录后没有 Role 信息。
    
- **原因**: 早期缺少 Database Trigger，`auth.users` 新增时未同步到 `profiles`。
    
- **修复**: 运行 3.3 节的 SQL 脚本，并手动修补旧数据。
    

---

## 5. 运维操作手册 (Operations Manual)

### Q1: 如何手动提升管理员?

_前端为了安全，没有做“注册管理员”的界面。_

1. 登录 Supabase Dashboard。
    
2. 进入 **Table Editor** -> **profiles** 表。
    
3. 找到你的账号行。
    
4. 将 `role` 列的值从 `user` 改为 `admin`。
    
5. 点击 **Save**。
    

### Q2: 如何更新版本?

_当你修改了核心 Auth 逻辑，必须强制用户更新缓存。_

1. 打开 `src/main.tsx`。
    
2. 修改 `const APP_VERSION = 'v1.x.x'` (数字加一)。
    
3. 推送到 Git，等待部署。
    

### Q3: 子应用如何接入?

_Gallery（已废弃）或 Note 等应用接入时注意：_

1. **Client 配置**: 不要设置 `schema: 'gallery'`，保持默认 `public`。
    
2. **SSO 链接**: 使用 `https://account.iasbt.com/login?redirect={你的子应用URL}`。
    

---

_End of Grand Master Documentation_
